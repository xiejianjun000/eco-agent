import { useState, useCallback } from 'react';
import LeftNav from './components/LeftNav';
import MiddleWorkArea from './components/MiddleWorkArea';
import RightToolPanel from './components/modules/RightPanel';
import { ENTERPRISES, type Enterprise } from './data/enterprises';
import { type ScanHit, scan, VETO_ITEMS, VETO_CATEGORIES } from './data/vetoItems';
import { type DocTemplate, DOC_TEMPLATES } from './data/docTemplates';
import {
  INITIAL_INSPECTION_TASKS,
  type ClassicCase,
  CLASSIC_CASES,
  KNOWLEDGE_ITEMS,
} from './data/knowledgeBase';
import { type BizPlatform, BIZ_PLATFORMS } from './data/platforms';
import { type DiscretionTable, DISCRETION_TABLES } from './data/discretionTables';
import './App.css';

export interface CaseFile {
  id: string;
  title: string;
  enterprise?: Enterprise;
  caseText?: string;
  vetoHits: ScanHit[];
  vetoPassed: boolean;
  archived: boolean;
  createdAt: string;
  hundredReviewNo?: number;
  discretionTableId?: string;
  evidenceCount?: number;
}

export interface InspectionTask {
  id: string;
  date: string;
  title: string;
  source: '督察管理';
}

export interface HermesLearnItem {
  id: string;
  date: string;
  content: string;
  status: 'done' | 'todo';
}

type NavId = 'assistant' | 'calendar' | 'map' | 'enterprises' | 'platforms' | 'enforcement' | 'inspection' | 'review' | 'archive' | 'knowledge' | 'mcp' | 'settings';
type CodeActionId = 'a1' | 'a2' | 'a3';

interface HundredProgress {
  done: number;
  inProgress: number;
  pending: number;
  recent: string;
}

function ensureUsage(
  _cl: ClassicCase[],
  _ki: typeof KNOWLEDGE_ITEMS,
  _bp: BizPlatform[],
  _dt: DiscretionTable[],
  _vi: typeof VETO_ITEMS,
  _vc: string[],
  _dtpl: DocTemplate[],
): void {
  void _cl; void _ki; void _bp; void _dt; void _vi; void _vc; void _dtpl;
}

ensureUsage(CLASSIC_CASES, KNOWLEDGE_ITEMS, BIZ_PLATFORMS, DISCRETION_TABLES, VETO_ITEMS, VETO_CATEGORIES, DOC_TEMPLATES);

function makeInitialCases(): { archived: CaseFile[]; current: CaseFile } {
  const sampleText = '现场检查笔录无签字。监测报告无CMA盖章。处罚前未履行告知程序。法条引用错误。';
  const hits = scan(sampleText);
  const e001 = ENTERPRISES[0];
  const e002 = ENTERPRISES[1];
  const archived1: CaseFile = {
    id: 'C-0072',
    title: '#72 赢湖矿产品加工厂固废露天堆放案',
    enterprise: e002,
    caseText: '已结案归档卷宗材料',
    vetoHits: [],
    vetoPassed: true,
    archived: true,
    createdAt: '2026-06-12',
    hundredReviewNo: 72,
    discretionTableId: DISCRETION_TABLES[2].id,
    evidenceCount: 9,
  };
  const archived2: CaseFile = {
    id: 'C-0071',
    title: '#71 鑫鑫环保建材大气超标排放案',
    enterprise: ENTERPRISES[2],
    caseText: '已归档',
    vetoHits: hits.slice(0, 2),
    vetoPassed: false,
    archived: true,
    createdAt: '2026-05-28',
    hundredReviewNo: 71,
    discretionTableId: DISCRETION_TABLES[1].id,
    evidenceCount: 6,
  };
  const current: CaseFile = {
    id: 'C-0073',
    title: '#73 金富源水污染案',
    enterprise: e001,
    caseText: sampleText,
    vetoHits: hits,
    vetoPassed: hits.length === 0,
    archived: false,
    createdAt: '2026-07-20',
    hundredReviewNo: 73,
    discretionTableId: DISCRETION_TABLES[0].id,
    evidenceCount: 11,
  };
  return { archived: [archived1, archived2], current };
}

function App(): JSX.Element {
  const initials = makeInitialCases();

  const [activeNav, setActiveNav] = useState<NavId>('review');
  const [dualLocked] = useState<boolean>(true);
  const [codeTransitionActions, setCodeTransitionActions] = useState<Record<CodeActionId, boolean>>({ a1: false, a2: false, a3: false });
  const [selectedEnterprise, setSelectedEnterprise] = useState<Enterprise | undefined>(undefined);
  const [officeDocName] = useState<string | undefined>(undefined);
  const [generatedDocs] = useState<(DocTemplate | { name: string })[] | undefined>(undefined);
  const [currentCase, setCurrentCase] = useState<CaseFile | undefined>(initials.current);
  const [archivedCases, setArchivedCases] = useState<CaseFile[]>(initials.archived);
  const [hundredProgress] = useState<HundredProgress>({
    done: 73,
    inProgress: 2,
    pending: 25,
    recent: '#73 金富源水污染案',
  });
  const [globalAlerts] = useState<Array<{ id: string; level: string; content: string }>>([]);

  const navigate = useCallback(
    (id: NavId, payload?: unknown): void => {
      setActiveNav(id);
      if (id === 'enforcement' && !selectedEnterprise) {
        const e001 = ENTERPRISES.find((e) => e.id === 'E001');
        if (e001) {
          setSelectedEnterprise(e001);
        }
      }
      if (payload && typeof payload === 'string') {
        void payload;
      }
    },
    [selectedEnterprise],
  );

  const handleSelectEnterprise = useCallback((e: Enterprise): void => {
    setSelectedEnterprise(e);
  }, []);

  const handleVetoScanComplete = useCallback(
    (caseText: string, hits: ScanHit[], passed: boolean): void => {
      setCurrentCase((prev) =>
        prev
          ? { ...prev, caseText, vetoHits: hits, vetoPassed: passed }
          : undefined,
      );
    },
    [],
  );

  const handleArchiveCurrentCase = useCallback((): void => {
    setCurrentCase((prev) => {
      if (!prev) return prev;
      const archived: CaseFile = { ...prev, archived: true };
      setArchivedCases((list) => [archived, ...list]);
      return undefined;
    });
  }, []);

  const handleBackToReviewFromKB = useCallback((c: CaseFile): void => {
    setCurrentCase(c);
    setActiveNav('review');
  }, []);

  const handleCodeActionToggle = useCallback((id: CodeActionId, done: boolean): void => {
    setCodeTransitionActions((prev) => ({ ...prev, [id]: done }));
  }, []);

  return (
    <div className="app-container" style={{ display: 'flex', width: '100%', height: '100vh', overflow: 'hidden' }}>
      <LeftNav
        activeNav={activeNav}
        dualLocked={dualLocked}
        hundredProgress={hundredProgress}
        navigate={navigate}
      />
      <MiddleWorkArea
        activeNav={activeNav}
        selectedEnterprise={selectedEnterprise}
        officeDocName={officeDocName}
        generatedDocs={generatedDocs}
        currentCase={currentCase}
        archivedCases={archivedCases}
        codeTransitionActions={codeTransitionActions}
        globalAlerts={globalAlerts}
        onSelectEnterprise={handleSelectEnterprise}
        onVetoScanComplete={handleVetoScanComplete}
        onArchiveCurrentCase={handleArchiveCurrentCase}
        onBackToReviewFromKB={handleBackToReviewFromKB}
        onCodeActionToggle={handleCodeActionToggle}
      />
      <RightToolPanel
        selectedEnterprise={selectedEnterprise}
        enterprises={ENTERPRISES}
        activeDocName={officeDocName}
      />
    </div>
  );
}

export default App;
export type { NavId, CodeActionId, HundredProgress };
export { ENTERPRISES as APP_ENTERPRISES, DOC_TEMPLATES as APP_DOC_TEMPLATES, INITIAL_INSPECTION_TASKS as APP_INITIAL_TASKS, BIZ_PLATFORMS as APP_BIZ_PLATFORMS, DISCRETION_TABLES as APP_DISCRETION_TABLES };
